import React, { useState } from 'react';
import { Search, MapPin, Calendar, Clock, Users, Music, Sparkles, Filter } from 'lucide-react';

interface Event {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  image: string;
  attendees: number;
  category: string;
}

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [showAllEvents, setShowAllEvents] = useState(false);

  const allEvents: Event[] = [
    {
      id: 1,
      title: "Zomer Strand Festival",
      date: "2024-07-15",
      time: "14:00",
      location: "Strand Amsterdam",
      image: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&q=80&w=1000",
      attendees: 5000,
      category: "Festival"
    },
    {
      id: 2,
      title: "Underground Techno Nacht",
      date: "2024-03-30",
      time: "22:00",
      location: "Club Neo, Rotterdam",
      image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&q=80&w=1000",
      attendees: 800,
      category: "Clubavond"
    },
    {
      id: 3,
      title: "Tuinfeest",
      date: "2024-06-01",
      time: "16:00",
      location: "Vondelpark, Amsterdam",
      image: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&q=80&w=1000",
      attendees: 300,
      category: "Buiten"
    },
    {
      id: 4,
      title: "Jazz in het Park",
      date: "2024-08-20",
      time: "19:00",
      location: "Westerpark, Amsterdam",
      image: "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?auto=format&fit=crop&q=80&w=1000",
      attendees: 1200,
      category: "Concert"
    },
    {
      id: 5,
      title: "Elektronisch Muziek Festival",
      date: "2024-09-10",
      time: "12:00",
      location: "RAI Amsterdam",
      image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=1000",
      attendees: 8000,
      category: "Festival"
    },
    {
      id: 6,
      title: "Dakfeest",
      date: "2024-07-05",
      time: "16:00",
      location: "W Hotel, Amsterdam",
      image: "https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&q=80&w=1000",
      attendees: 400,
      category: "Feest"
    }
  ];

  const categories = [...new Set(allEvents.map(event => event.category))];

  const filteredEvents = allEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || event.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredEvents = allEvents.slice(0, 3);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-indigo-900">
      {/* Hero Section */}
      <div className="relative h-[500px] flex items-center justify-center">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=1000" 
            alt="Feest achtergrond"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-8">
            Waar is het feestje?
          </h1>
          <p className="text-xl text-purple-200 mb-12">
            Vind de leukste feesten en evenementen in Nederland
          </p>
          <div className="relative max-w-2xl mx-auto">
            <input
              type="text"
              placeholder="Zoek evenementen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-6 py-4 rounded-full bg-white/10 backdrop-blur-md text-white placeholder-purple-200 border-2 border-purple-400/30 focus:outline-none focus:border-purple-400 transition"
            />
            <Search className="absolute right-6 top-1/2 transform -translate-y-1/2 text-purple-200" />
          </div>
        </div>
      </div>

      {/* View Toggle */}
      <div className="max-w-7xl mx-auto px-4 pt-16">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-white flex items-center gap-2">
            {showAllEvents ? (
              <>
                <Filter className="text-purple-400" />
                Alle Evenementen
              </>
            ) : (
              <>
                <Sparkles className="text-purple-400" />
                Uitgelichte Evenementen
              </>
            )}
          </h2>
          <button
            onClick={() => setShowAllEvents(!showAllEvents)}
            className="px-6 py-2 rounded-full bg-purple-500 text-white hover:bg-purple-400 transition"
          >
            {showAllEvents ? 'Toon Uitgelicht' : 'Bekijk Alles'}
          </button>
        </div>

        {/* Category Filter */}
        {showAllEvents && (
          <div className="mb-8 flex gap-4 overflow-x-auto pb-4">
            <button
              onClick={() => setSelectedCategory('')}
              className={`px-4 py-2 rounded-full ${
                selectedCategory === '' 
                  ? 'bg-purple-500 text-white' 
                  : 'bg-white/10 text-purple-200 hover:bg-white/20'
              } transition whitespace-nowrap`}
            >
              Alle Categorieën
            </button>
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full ${
                  selectedCategory === category 
                    ? 'bg-purple-500 text-white' 
                    : 'bg-white/10 text-purple-200 hover:bg-white/20'
                } transition whitespace-nowrap`}
              >
                {category}
              </button>
            ))}
          </div>
        )}

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-16">
          {(showAllEvents ? filteredEvents : featuredEvents).map((event) => (
            <div key={event.id} className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden hover:transform hover:scale-105 transition duration-300">
              <img 
                src={event.image} 
                alt={event.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center gap-2 text-purple-400 text-sm mb-2">
                  <Music size={16} />
                  {event.category}
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{event.title}</h3>
                <div className="space-y-2 text-purple-200">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    {new Date(event.date).toLocaleDateString('nl-NL')}
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    {event.time} uur
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin size={16} />
                    {event.location}
                  </div>
                  <div className="flex items-center gap-2">
                    <Users size={16} />
                    {event.attendees} bezoekers
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;